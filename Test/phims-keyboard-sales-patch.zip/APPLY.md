# Keyboard-first Encode Sales patch

1. Replace `client/src/pages/Sales.jsx` with the file in this patch.
2. Copy `client/src/styles/keyboard-encode.css` into the project.
3. In `client/src/main.jsx`, add:

```js
import './styles/keyboard-encode.css';
```

4. Rebuild:

```powershell
cd C:\PhIMS\client
npm run build
cd ..
npm start
```

## Controls

- `Enter` from the invoice field or workspace: open product selector
- Barcode/item code + `Enter`: add matching product
- Type letters/numbers in product selector: incremental name search
- `Arrow Up` / `Arrow Down`: move between products or sale rows
- `Enter` in product selector: add selected product
- `Backspace` or `Escape`: close selector
- `Q` on sale row: quantity dialog
- `D` on sale row: toggle discount
- `F2` or `Delete` on sale row: remove row
- `F4`: discount percentage and remarks dialog
- `F5`: validate and save
- `F9`: clear current unsaved sale
- `F10`: return home

The backend still validates stock, prices, discounts, and invoice uniqueness.
