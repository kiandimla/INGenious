import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Layout from '../components/Layout';
import Notice from '../components/Notice';
import { api, money } from '../api/client';

const normalize = value => String(value || '').toLowerCase().replace(/[^a-z0-9]/g, '');

export default function Sales() {
  const navigate = useNavigate();
  const invoiceRef = useRef(null);
  const quantityRef = useRef(null);
  const discountRef = useRef(null);
  const remarksRef = useRef(null);
  const productRowRefs = useRef([]);
  const saleRowRefs = useRef([]);
  const barcode = useRef({ value: '', lastKeyAt: 0 });
  const search = useRef({ value: '', timer: null });

  const [products, setProducts] = useState([]);
  const [invoiceNumber, setInvoiceNumber] = useState('');
  const [discountPercent, setDiscountPercent] = useState(20);
  const [discountRemarks, setDiscountRemarks] = useState('');
  const [items, setItems] = useState([]);
  const [selectedSaleIndex, setSelectedSaleIndex] = useState(-1);
  const [selectedProductIndex, setSelectedProductIndex] = useState(0);
  const [overlay, setOverlay] = useState(null);
  const [quantityDraft, setQuantityDraft] = useState('');
  const [discountDraft, setDiscountDraft] = useState('20');
  const [remarksDraft, setRemarksDraft] = useState('');
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState('error');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api('/api/products/available')
      .then(response => setProducts(response.products))
      .catch(error => showMessage(error.message));
  }, []);

  useEffect(() => {
    invoiceRef.current?.focus();
  }, []);

  useEffect(() => {
    if (overlay === 'products') productRowRefs.current[selectedProductIndex]?.focus();
    if (overlay === 'quantity') quantityRef.current?.focus();
    if (overlay === 'discount') discountRef.current?.focus();
  }, [overlay, selectedProductIndex]);

  useEffect(() => () => clearTimeout(search.current.timer), []);

  const showMessage = useCallback((text, type = 'error') => {
    setMessage(text);
    setMessageType(type);
  }, []);

  const focusSaleRow = useCallback(index => {
    if (!items.length) {
      invoiceRef.current?.focus();
      return;
    }
    const bounded = Math.max(0, Math.min(index, items.length - 1));
    setSelectedSaleIndex(bounded);
    requestAnimationFrame(() => saleRowRefs.current[bounded]?.focus());
  }, [items.length]);

  const addProduct = useCallback(product => {
    let focusIndex = 0;
    let stockWarning = null;
    setItems(current => {
      const existingIndex = current.findIndex(item => item.productId === product.itemId);
      if (existingIndex >= 0) {
        focusIndex = existingIndex;
        return current.map((item, index) => {
          if (index !== existingIndex) return item;
          const nextQuantity = Math.min(item.quantity + 1, product.quantity);
          if (nextQuantity === item.quantity) stockWarning = `Maximum available quantity is ${product.quantity}`;
          return { ...item, quantity: nextQuantity };
        });
      }
      focusIndex = current.length;
      return [...current, {
        productId: product.itemId,
        name: product.itemName,
        priceCentavos: product.priceCentavos,
        available: product.quantity,
        quantity: 1,
        applyDiscount: false
      }];
    });
    setOverlay(null);
    setSelectedSaleIndex(focusIndex);
    requestAnimationFrame(() => saleRowRefs.current[focusIndex]?.focus());
    if (stockWarning) showMessage(stockWarning);
  }, [showMessage]);

  const grossCentavos = useMemo(
    () => items.reduce((sum, item) => sum + item.priceCentavos * item.quantity, 0),
    [items]
  );
  const discountCentavos = useMemo(
    () => items.reduce((sum, item) => sum + (item.applyDiscount
      ? Math.round(item.priceCentavos * item.quantity * discountPercent / 100)
      : 0), 0),
    [items, discountPercent]
  );
  const netCentavos = grossCentavos - discountCentavos;
  const vatCentavos = Math.round(netCentavos * 12 / 112);

  const openProducts = useCallback(() => {
    if (!products.length) return showMessage('No products with available inventory.');
    setOverlay('products');
    setSelectedProductIndex(0);
  }, [products.length, showMessage]);

  const closeOverlay = useCallback(() => {
    setOverlay(null);
    requestAnimationFrame(() => {
      if (selectedSaleIndex >= 0) saleRowRefs.current[selectedSaleIndex]?.focus();
      else invoiceRef.current?.focus();
    });
  }, [selectedSaleIndex]);

  const openQuantity = useCallback(() => {
    if (selectedSaleIndex < 0 || !items[selectedSaleIndex]) return;
    setQuantityDraft(String(items[selectedSaleIndex].quantity));
    setOverlay('quantity');
  }, [items, selectedSaleIndex]);

  const commitQuantity = useCallback(() => {
    const item = items[selectedSaleIndex];
    if (!item) return closeOverlay();
    const requested = Number.parseInt(quantityDraft, 10);
    if (!Number.isInteger(requested) || requested < 1) {
      showMessage('Quantity must be at least 1.');
      return;
    }
    const quantity = Math.min(requested, item.available);
    setItems(current => current.map((value, index) => index === selectedSaleIndex ? { ...value, quantity } : value));
    if (requested > item.available) showMessage(`Maximum available quantity is ${item.available}`);
    closeOverlay();
  }, [closeOverlay, items, quantityDraft, selectedSaleIndex, showMessage]);

  const openDiscount = useCallback(() => {
    setDiscountDraft(String(discountPercent || 20));
    setRemarksDraft(discountRemarks);
    setOverlay('discount');
  }, [discountPercent, discountRemarks]);

  const commitDiscount = useCallback(() => {
    const number = Number.parseInt(discountDraft || '20', 10);
    if (!Number.isInteger(number) || number < 0 || number > 99) {
      showMessage('Discount must be between 0 and 99.');
      return;
    }
    setDiscountPercent(number);
    setDiscountRemarks(remarksDraft.trim());
    closeOverlay();
  }, [closeOverlay, discountDraft, remarksDraft, showMessage]);

  const toggleDiscount = useCallback(() => {
    if (selectedSaleIndex < 0) return;
    setItems(current => current.map((item, index) => index === selectedSaleIndex
      ? { ...item, applyDiscount: !item.applyDiscount }
      : item));
  }, [selectedSaleIndex]);

  const removeSelected = useCallback(() => {
    if (selectedSaleIndex < 0) return;
    setItems(current => current.filter((_, index) => index !== selectedSaleIndex));
    const nextIndex = Math.max(0, selectedSaleIndex - 1);
    requestAnimationFrame(() => focusSaleRow(nextIndex));
  }, [focusSaleRow, selectedSaleIndex]);

  const saveSale = useCallback(async () => {
    if (saving) return;
    if (!items.length) return showMessage('Sale has no items.');
    if (!invoiceNumber.trim()) {
      showMessage('SI Number is empty.');
      invoiceRef.current?.focus();
      return;
    }
    try {
      setSaving(true);
      const response = await api('/api/sales', {
        method: 'POST',
        body: JSON.stringify({
          invoiceNumber,
          discountPercent,
          discountRemarks,
          items: items.map(({ productId, quantity, applyDiscount }) => ({
            productId, quantity, applyDiscount
          }))
        })
      });
      setItems([]);
      setSelectedSaleIndex(-1);
      setInvoiceNumber(response.sale.nextSuggestedInvoice || '');
      showMessage(`Invoice ${response.sale.invoiceNumber} saved.`, 'success');
      requestAnimationFrame(() => invoiceRef.current?.focus());
    } catch (error) {
      showMessage(error.message);
    } finally {
      setSaving(false);
    }
  }, [discountPercent, discountRemarks, invoiceNumber, items, saving, showMessage]);

  const handleProductSearch = useCallback(key => {
    clearTimeout(search.current.timer);
    search.current.value += normalize(key);
    search.current.timer = setTimeout(() => { search.current.value = ''; }, 500);
    const needle = search.current.value;
    let index = products.findIndex(product => normalize(product.itemName).startsWith(needle));
    if (index < 0) index = products.findIndex(product => normalize(product.itemName).includes(needle));
    if (index >= 0) setSelectedProductIndex(index);
  }, [products]);

  const handleProductKeyDown = useCallback(event => {
    if (event.key === 'ArrowDown') {
      event.preventDefault();
      setSelectedProductIndex(index => Math.min(index + 1, products.length - 1));
    } else if (event.key === 'ArrowUp') {
      event.preventDefault();
      setSelectedProductIndex(index => Math.max(index - 1, 0));
    } else if (event.key === 'Enter') {
      event.preventDefault();
      addProduct(products[selectedProductIndex]);
    } else if (event.key === 'Backspace' || event.key === 'Escape') {
      event.preventDefault();
      closeOverlay();
    } else if (event.key.length === 1 && /[a-z0-9]/i.test(event.key)) {
      handleProductSearch(event.key);
    }
  }, [addProduct, closeOverlay, handleProductSearch, products, selectedProductIndex]);

  useEffect(() => {
    function onKeyDown(event) {
      if (event.repeat && ['F2', 'F4', 'F5', 'F9', 'F10'].includes(event.key)) return;

      if (event.key === 'F5') {
        event.preventDefault();
        saveSale();
        return;
      }
      if (event.key === 'F9') {
        event.preventDefault();
        setItems([]);
        setSelectedSaleIndex(-1);
        setMessage('');
        invoiceRef.current?.focus();
        return;
      }
      if (event.key === 'F10') {
        event.preventDefault();
        navigate('/home');
        return;
      }
      if (event.key === 'F4' && !overlay) {
        event.preventDefault();
        openDiscount();
        return;
      }
      if (overlay) return;

      const target = event.target;
      const isTextInput = target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement;
      if (selectedSaleIndex >= 0 && !isTextInput) {
        if (event.key === 'ArrowDown') {
          event.preventDefault();
          focusSaleRow(selectedSaleIndex + 1);
          return;
        }
        if (event.key === 'ArrowUp') {
          event.preventDefault();
          focusSaleRow(selectedSaleIndex - 1);
          return;
        }
        if (event.key.toLowerCase() === 'd') {
          event.preventDefault();
          toggleDiscount();
          return;
        }
        if (event.key.toLowerCase() === 'q') {
          event.preventDefault();
          openQuantity();
          return;
        }
        if (event.key === 'F2' || event.key === 'Delete') {
          event.preventDefault();
          removeSelected();
          return;
        }
      }

      const now = performance.now();
      if (event.key.length === 1 && !event.ctrlKey && !event.altKey && !event.metaKey) {
        if (now - barcode.current.lastKeyAt > 35) barcode.current.value = '';
        barcode.current.lastKeyAt = now;
        barcode.current.value += event.key;
      } else if (event.key === 'Enter') {
        const scanned = barcode.current.value;
        barcode.current.value = '';
        if (scanned.length >= 2 && now - barcode.current.lastKeyAt < 100) {
          const product = products.find(value => value.itemId.toLowerCase() === scanned.toLowerCase());
          if (product) {
            event.preventDefault();
            addProduct(product);
          } else if (!isTextInput) {
            event.preventDefault();
            showMessage(`Item with barcode ${scanned} not found.`);
          }
          return;
        }
        if (!isTextInput || target === invoiceRef.current) {
          event.preventDefault();
          openProducts();
        }
      } else if (event.key === 'Backspace' && !isTextInput) {
        event.preventDefault();
        closeOverlay();
      }
    }
    document.addEventListener('keydown', onKeyDown);
    return () => document.removeEventListener('keydown', onKeyDown);
  }, [addProduct, closeOverlay, focusSaleRow, navigate, openDiscount, openProducts, openQuantity, overlay, products, removeSelected, saveSale, selectedSaleIndex, showMessage, toggleDiscount]);

  return <Layout title="Encode Sales">
    <section className={`encode-workspace ${overlay ? 'is-blurred' : ''}`}>
      <div className="encode-bar">
        <label>SI
          <input ref={invoiceRef} value={invoiceNumber}
            onChange={event => setInvoiceNumber(event.target.value.replace(/\D/g, ''))}
            placeholder="SI Number" />
        </label>
        <div>Discount: <strong>{discountPercent}%</strong></div>
        <div className="shortcut-strip">Enter Items · Q Quantity · D Discount · F2 Remove · F4 Discount Setup · F5 Save · F9 Clear · F10 Home</div>
      </div>

      <Notice message={message} type={messageType} />

      <div className="table-wrap encode-main-table">
        <table>
          <thead><tr><th>Qty</th><th>Description</th><th>Unit Price</th><th>Apply Discount</th><th>Amount</th></tr></thead>
          <tbody>
            {items.map((item, index) => {
              const discount = item.applyDiscount ? Math.round(item.priceCentavos * item.quantity * discountPercent / 100) : 0;
              return <tr key={item.productId} ref={element => saleRowRefs.current[index] = element}
                tabIndex="0" className={index === selectedSaleIndex ? 'keyboard-selected' : ''}
                onFocus={() => setSelectedSaleIndex(index)}>
                <td>{item.quantity}</td><td>{item.name}</td><td>{money(item.priceCentavos)}</td>
                <td><input tabIndex="-1" type="checkbox" checked={item.applyDiscount}
                  onChange={() => { setSelectedSaleIndex(index); toggleDiscount(); }} /></td>
                <td>{money(item.priceCentavos * item.quantity - discount)}</td>
              </tr>;
            })}
            <tr className="table-footer"><td colSpan="3"></td><td>Subtotal:</td><td>{money(grossCentavos)}</td></tr>
            <tr className="table-footer"><td colSpan="3"></td><td>Discounts:</td><td>{money(discountCentavos)}</td></tr>
            <tr className="table-footer"><td colSpan="3"></td><td>VAT (12% included):</td><td>{money(vatCentavos)}</td></tr>
            <tr className="table-footer total"><td colSpan="3"></td><td>Total:</td><td>{money(netCentavos)}</td></tr>
          </tbody>
        </table>
      </div>
    </section>

    {overlay === 'products' && <div className="encode-overlay" role="dialog" aria-modal="true">
      <div className="selector-panel" onKeyDown={handleProductKeyDown}>
        <div className="price-display">{money(products[selectedProductIndex]?.priceCentavos || 0)}</div>
        <div className="selector-scroll">
          <table><thead><tr><th>Description</th><th>Price</th><th>Item Code</th><th>Stock</th></tr></thead>
            <tbody>{products.map((product, index) => <tr key={product.itemId}
              ref={element => productRowRefs.current[index] = element} tabIndex="0"
              className={index === selectedProductIndex ? 'keyboard-selected' : ''}
              onFocus={() => setSelectedProductIndex(index)} onDoubleClick={() => addProduct(product)}>
              <td>{product.itemName}</td><td>{money(product.priceCentavos)}</td><td>{product.itemId}</td><td>{product.quantity}</td>
            </tr>)}</tbody></table>
        </div>
        <div className="overlay-help">Type to search · ↑/↓ Navigate · Enter Add · Backspace/Esc Close</div>
      </div>
    </div>}

    {overlay === 'quantity' && <div className="encode-overlay" role="dialog" aria-modal="true">
      <div className="entry-panel"><h2>Enter Quantity</h2><input ref={quantityRef} inputMode="numeric"
        value={quantityDraft} onChange={event => setQuantityDraft(event.target.value.replace(/\D/g, '').slice(0, 4))}
        onKeyDown={event => { if (event.key === 'Enter') commitQuantity(); if (event.key === 'Escape') closeOverlay(); }} />
        <p>Available: {items[selectedSaleIndex]?.available || 0}</p></div>
    </div>}

    {overlay === 'discount' && <div className="encode-overlay" role="dialog" aria-modal="true">
      <div className="entry-panel"><h2>Enter Discount</h2><input ref={discountRef} inputMode="numeric"
        value={discountDraft} placeholder="20"
        onChange={event => setDiscountDraft(event.target.value.replace(/\D/g, '').slice(0, 2))}
        onKeyDown={event => { if (event.key === 'Enter') remarksRef.current?.focus(); if (event.key === 'Escape') closeOverlay(); }} />
        <input ref={remarksRef} value={remarksDraft} placeholder="Remarks"
          onChange={event => setRemarksDraft(event.target.value)}
          onKeyDown={event => { if (event.key === 'Enter') commitDiscount(); if (event.key === 'Escape') closeOverlay(); }} />
        <p>Enter after remarks to apply.</p></div>
    </div>}
  </Layout>;
}
