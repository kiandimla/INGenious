# Add the React frontend

Copy `client/` and the two `src/` replacement files into the existing PhIMS backend project.

From the project root:

```powershell
cd client
npm install
npm run build
cd ..
npm start
```

Open `http://127.0.0.1:3000`.

For development with automatic refresh, run the backend in one terminal and this in another:

```powershell
cd client
npm run dev
```

Then open `http://127.0.0.1:5173`.

The interface intentionally uses locally bundled CSS and text/emoji placeholders rather than the unavailable image assets. No CDN is used.
