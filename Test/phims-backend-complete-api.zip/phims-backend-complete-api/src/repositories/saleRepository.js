function createSaleRepository(db) {
  return {
    findByInvoice(invoiceNumber) {
      return db.prepare('SELECT * FROM sales WHERE invoice_number = ? COLLATE NOCASE').get(invoiceNumber);
    },
    createSale(value) {
      return db.prepare(`INSERT INTO sales
        (invoice_number, sale_date, gross_total_centavos, discount_total_centavos,
         vat_total_centavos, net_total_centavos, encoded_by_user_id)
        VALUES (@invoiceNumber, @saleDate, @grossTotalCentavos, @discountTotalCentavos,
                @vatTotalCentavos, @netTotalCentavos, @userId)`).run(value).lastInsertRowid;
    },
    insertItem(value) {
      return db.prepare(`INSERT INTO sale_items
        (sale_id, product_id, item_name_snapshot, unit_price_centavos, unit_cost_centavos,
         quantity, discount_percent_basis_points, is_discounted, discount_remarks,
         gross_subtotal_centavos, discount_amount_centavos, vat_amount_centavos,
         net_subtotal_centavos)
        VALUES (@saleId, @productId, @itemName, @unitPriceCentavos, @unitCostCentavos,
                @quantity, @discountBasisPoints, @isDiscounted, @discountRemarks,
                @grossSubtotalCentavos, @discountAmountCentavos, @vatAmountCentavos,
                @netSubtotalCentavos)`).run(value).lastInsertRowid;
    },
    decrementStock(productId, quantity) {
      return db.prepare(`UPDATE stock_quantities
        SET quantity = quantity - ?, updated_at = CURRENT_TIMESTAMP
        WHERE product_id = ? AND quantity >= ?`).run(quantity, productId, quantity);
    },
    addMovement(value) {
      db.prepare(`INSERT INTO stock_movements
        (product_id, movement_type, quantity_change, stock_before, stock_after,
         sale_item_id, reason, created_by_user_id)
        VALUES (@productId, 'SALE', @quantityChange, @stockBefore, @stockAfter,
                @saleItemId, @reason, @userId)`).run(value);
    },
    nextSuggestedInvoice(invoiceNumber) {
      if (!/^\d+$/.test(invoiceNumber)) return null;
      return String(BigInt(invoiceNumber) + 1n).padStart(invoiceNumber.length, '0');
    }
  };
}
module.exports = { createSaleRepository };
