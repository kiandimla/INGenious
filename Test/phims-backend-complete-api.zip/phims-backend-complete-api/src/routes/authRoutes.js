const express = require('express');
const bcrypt = require('bcryptjs');
function createAuthRoutes(users) {
  const router = express.Router();
  router.post('/login', async (req, res, next) => {
    try {
      const name = String(req.body.name ?? '').trim();
      const password = String(req.body.password ?? '');
      const user = users.findByName(name);
      const valid = user && user.isActive && await bcrypt.compare(password, user.passwordHash);
      if (!valid) return res.status(401).json({ error: { code: 'INVALID_LOGIN', message: 'Invalid name or password.' } });
      await new Promise((resolve, reject) => req.session.regenerate(error => error ? reject(error) : resolve()));
      req.session.user = { id: user.id, name: user.name, isAdmin: Boolean(user.isAdmin) };
      res.json({ user: req.session.user });
    } catch (error) { next(error); }
  });
  router.post('/logout', (req, res, next) => {
    req.session.destroy(error => {
      if (error) return next(error);
      res.clearCookie('phims.sid');
      res.status(204).end();
    });
  });
  router.get('/session', (req, res) => res.json({ user: req.session.user || null }));
  return router;
}
module.exports = { createAuthRoutes };
