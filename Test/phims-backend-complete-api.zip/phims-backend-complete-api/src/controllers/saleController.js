function createSaleController(service) {
  return {
    create(req, res, next) {
      try {
        const sale = service.create(req.body, req.session.user.id);
        res.status(201).json({ sale });
      } catch (error) { next(error); }
    }
  };
}
module.exports = { createSaleController };
