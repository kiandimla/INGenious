# PhIMS SQLite foundation

## How table creation works

`src/db/migrations/001_initial_schema.sql` is the SQL script that creates the SQLite tables, indexes, constraints, and trigger.

`src/db/migrate.js` is the migration runner. On startup, `app.js` runs every numbered SQL file that has not yet been recorded in `schema_migrations`. This means the app creates a new database automatically and upgrades an existing database without rerunning old migrations.

`src/db/migrations/002_seed_plu.sql` imports the supplied PLU workbook. The import uses text product IDs/codes and integer centavos for money.

## Run

```bash
npm install
```

Set a session secret.

Windows PowerShell:

```powershell
$env:SESSION_SECRET='replace-with-a-long-random-secret'
npm start
```

Command Prompt:

```bat
set SESSION_SECRET=replace-with-a-long-random-secret
npm start
```

The database is created at `data/phims.sqlite3`.

## Verify

```bash
npm run db:verify
```

## Backup

Stop the app, then copy these files:

```text
data/phims.sqlite3
data/sessions.sqlite3
```

For a live backup, use SQLite's `.backup` command when the SQLite CLI is available:

```bash
sqlite3 data/phims.sqlite3 ".backup 'phims-backup.sqlite3'"
```

## Restore

Stop the app, replace `data/phims.sqlite3` with a verified backup, and restart. Run `npm run db:verify` before normal use.

## Important

This package is the database and Express composition foundation. The complete sales, delivery, reporting, user, and React API modules still depend on the supplied HBS forms so their exact payloads and intended calculations can be preserved.

## Sales API implemented from the original Encode Sales screen

Create the first administrator:

```bash
npm run user:create-admin -- "Administrator" "a-long-offline-password"
```

React will use:

```text
POST /api/auth/login
POST /api/auth/logout
GET  /api/auth/session
GET  /api/products/available
POST /api/sales
```

Example sale body:

```json
{
  "invoiceNumber": "000123",
  "discountPercent": 20,
  "discountRemarks": "Senior",
  "items": [
    { "productId": "10", "quantity": 2, "applyDiscount": true },
    { "productId": "100", "quantity": 1, "applyDiscount": false }
  ]
}
```

The server ignores browser-provided names, prices, totals, and available quantities. It reloads all authoritative values from SQLite, recalculates totals, validates stock, inserts the invoice and line items, deducts stock, and writes stock movements in one `BEGIN IMMEDIATE` transaction.

## Delivery API

```text
POST /api/deliveries
```

Example request:

```json
{
  "supplier": "TGP PHARMA",
  "purpose": "DELIVERIES",
  "invoiceNumber": "SI12345",
  "deliveryDate": "2026-07-13",
  "pageNumber": 1,
  "pageCount": 3,
  "remarks": "Regular replenishment",
  "items": [
    { "productId": "10", "quantity": 20, "unitCost": "1.84", "expiryDate": "2027-12-31" },
    { "productId": "100", "quantity": 10, "unitCost": "2.55", "expiryDate": "2028-06-30" }
  ]
}
```

The old combined remarks value (`SI12345 07/13/2026 1/3`) is now represented as separate validated fields. React may still display or parse that compact form for operator convenience.

## Inventory API

```text
GET   /api/inventory
POST  /api/inventory/products                         administrator only
PATCH /api/inventory/products/:itemId/pricing         administrator only
```

Create a product:

```json
{
  "itemId": "NEW001",
  "itemName": "NEW PRODUCT",
  "price": "25.00",
  "cost": "15.50",
  "isPerishable": false
}
```

Update price and cost:

```json
{ "price": "27.00", "cost": "16.25" }
```

New products receive zero stock automatically. Stock quantity is not editable through the product-pricing endpoint; quantity changes must use a delivery or an audited stock-adjustment transaction.

## User administration API

All user-management endpoints require an authenticated administrator session:

```text
GET    /api/users
POST   /api/users
DELETE /api/users/:id
```

Create a user:

```json
{
  "name": "Cashier One",
  "resetKey": "private-reset-key",
  "password": "strong-password",
  "isAdmin": false
}
```

Passwords and reset keys are hashed with bcrypt before storage. The API never returns either hash.

Deletion is implemented as deactivation so historical sales, deliveries, and stock movements retain their user references. The signed-in account and administrator accounts cannot be deactivated from the Users screen, preserving the original workflow.

## Reports and records API

```text
GET /api/reports/sales?start=YYYY-MM-DD&end=YYYY-MM-DD&aggregate=daily|weekly|monthly|yearly
GET /api/reports/profit?start=...&end=...&aggregate=...        administrator only
GET /api/reports/deliveries?start=...&end=...
GET /api/reports/item-performance?start=...&end=...
GET /api/reports/stock-card?start=...&end=...&aggregate=...
GET /api/reports/item-aging
GET /api/reports/optimal-orders
GET /api/reports/records
```

Report totals are calculated by the server. PDF export remains a React/browser responsibility using the existing locally bundled PDF library, so the application needs no CDN or internet connection.
