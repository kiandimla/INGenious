# Apply runtime fix

1. Copy `src/config/sessionSecret.js` into the same path in the project.
2. In `app.js`, remove:

```js
const SQLiteStore = require('connect-sqlite3')(session);
```

3. Add with the other local imports:

```js
const { loadOrCreateSessionSecret } = require('./src/config/sessionSecret');
```

4. Immediately after `DATA_DIR` and `DB_PATH` are defined and the data directory is created, add:

```js
const SESSION_SECRET = loadOrCreateSessionSecret(DATA_DIR);
```

5. Remove the `if (!process.env.SESSION_SECRET) ...` warning block.
6. Replace the session configuration with:

```js
app.use(session({
  name: 'phims.sid',
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  rolling: true,
  cookie: {
    httpOnly: true,
    sameSite: 'strict',
    secure: false,
    maxAge: 8 * 60 * 60 * 1000
  }
}));
```

7. In `package.json`, remove the `connect-sqlite3` dependency.
8. In `src/services/userService.js`, change the password minimum from 10 to 3 and update the message to `Password must contain 3-200 characters.`
9. In `src/db/create-admin.js`, change `password.length < 10` to `password.length < 3` and update its usage message.
10. Clean and reinstall:

```powershell
Remove-Item .\node_modules -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item .\package-lock.json -Force -ErrorAction SilentlyContinue
npm install
npm start
```
